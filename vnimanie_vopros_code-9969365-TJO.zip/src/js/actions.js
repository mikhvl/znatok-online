function check_answer(context) {
    addAction({ type: "check_answer" }, context);
}
function enter_answer(answer, context) {
    addAction({ type: "enter_answer", answer: answer }, context);
}
function next_question(context) {
    addAction({ type: "next_question" }, context);
}
function read_question(context) {
    addAction({ type: "read_question" }, context);
}
function start_game(context) {
    addAction({ type: "start_game" }, context);
}
function restart_game(context) {
    addAction({ type: "restart_game" }, context);
}