function get_request(context) {
    if (context && context.request) return context.request.rawRequest;
    return {}
}
function get_server_action(request){
    if (request && request.payload && request.payload.data && request.payload.data.server_action){
        return request.payload.data.server_action;
    }
    return {};
}
