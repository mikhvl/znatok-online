function reply(body, response){
    var replyData = { type: "raw", body: body };
    response.replies = response.replies || [];
    response.replies.push(replyData);
}
function addAction(action, context){
    var command = { type: "smart_app_data", action: action };
    reply({items: [{command: command}]}, context.response);
}
function addSuggestions(suggestions, context) {
    var buttons = [];
    suggestions.forEach (function(suggest) {
        buttons.push({ action: { text: suggest, type: "text" }, title: suggest });
    });
    reply({"suggestions": {"buttons": buttons}}, context.response);
}
