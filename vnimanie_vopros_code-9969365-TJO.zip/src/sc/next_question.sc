theme: /
    state: СледующийВопрос
        q!: (~Следующий вопрос|~следующий|~Следующий)
        event!: server_action

        a: Новый вопрос готов!

        script:
            next_question($context);
            addSuggestions(["Прочитать", "Проверить", "Следующий вопрос"], $context);