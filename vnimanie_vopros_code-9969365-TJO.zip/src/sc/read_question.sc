theme: /
    state: ЧитатьВопрос
        q!: (*Прочитать*|прочитай|прочитайте)
        event!: server_action

        script:
            var sa = get_server_action($context.request);
            if (sa.type == "read_question") {
                var data = sa.eventData || {};
                a: data.value || "Вопрос загружается.";
            } else {
                read_question($context);
            }
            addSuggestions(["Прочитать", "Проверить", "Следующий вопрос"], $context);