theme: /
    state: ОзвучиваниеОтвета
        event!: read_q
            
           
        script:
            log('read_answer: context: ' + JSON.stringify($context))
            ### Пример обработки сообщения, отправленного из фронтенда с помощью sendData()
             var eventData = $context && $context.request && $context.request.data && $context.request.data.eventData || {}
            log('n: eventData: ' + JSON.stringify($context && $context.request && $context.request.data && $context.request.data.eventData))
            $reactions.answer({
                "value": eventData.value,
            });
            addSuggestions(["Прочитать", "Проверить", "Следующий вопрос", "Ответ - 'Пушкин'"], $context);