theme: /
    state: ПроверкаЭлемента
        q!: (~проверить|*не знаю*|скажи ответ|какой ответ|я не знаю|хз|проверь|проверьте)
        event!: server_action

        if: $request.rawRequest.payload.character.name === "Джой"
            a: Ответ принят. Скажи «Проверить», чтобы узнать результат.
        else:
            a: Ответ принят. Скажите «Проверить», чтобы узнать результат.

        script:
            var sa = get_server_action($context.request);
            if (sa.type == "check_answer") {
                var data = sa.eventData || {};
                a: data.value || "Результат готов.";
            }
            addSuggestions(["Прочитать", "Проверить", "Следующий вопрос"], $context);