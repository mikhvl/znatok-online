theme: /
    state: ДобавлениеЭлемента
        q!: (~ответ|мой ответ) $AnyText::anyText
        event!: server_action

        if: $request.rawRequest.payload.character.name === "Джой"
            a: Ответ принят! Для проверки скажи «Проверить».
        else:
            a: Ответ принят! Для проверки скажите «Проверить».

        script:
            var sa = get_server_action($context.request);
            if (sa.type == "enter_answer" || $parseTree._anyText) {
                enter_answer(sa.answer || $parseTree._anyText, $context);
            }
            addSuggestions(["Прочитать", "Проверить", "Следующий вопрос"], $context);